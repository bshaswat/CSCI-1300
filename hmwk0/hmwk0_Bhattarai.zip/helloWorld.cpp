#include <iostream>
using namespace std;

int main(){
    cout << "Hello World!, Hello CSCI 1300" << endl;
}


// CS1300 Fall 2020
// Author: Shaswat Bhattarai
// Recitation: 328 
// Homework 2 - Problem # 1  

#include <iostream>
using namespace std;

int main(){
    cout << "Hello, World!" << endl;
    return 0;
}
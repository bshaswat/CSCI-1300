// CS1300 Fall 2020
// Author: Shaswat Bhattarai
// Recitation: 328 
// Homework 2 - Problem # 2 

#include <iostream>
using namespace std;

int main(){
    string name;

    cout << "Enter your name: " << endl;
    cin >> name;

    cout << "Hello, " << name << "!" << endl;

    return 0;
}
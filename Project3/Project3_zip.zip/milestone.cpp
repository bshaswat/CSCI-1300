// CS1300 Fall 2020
// Author: Shaswat Bhattarai
// Recitation: 328
// Project 3

#include <iostream>
#include "milestones.h"
using namespace std;

milestone::milestone(){

}

int milestone::setdistance_travelled(){
    // function to calculate distance travelled
}

int milestone::setdistance_left(){
    // function to calculate distance left
}

int milestone::settime_passed(){
    // function to calculate time passed
}

int milestone::settime_left(){
    // function to calculate time left
}

string milestone::setnext_milestone(){
    // function to calculate next milestone
}


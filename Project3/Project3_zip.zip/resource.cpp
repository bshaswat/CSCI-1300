// CS1300 Fall 2020
// Author: Shaswat Bhattarai
// Recitation: 328
// Project 3

#include <iostream>
#include "resource.h"
using namespace std;

Resource::Resource(){

}

Resource::Resource(string teamname){

}

int Resource::setoxen(){
    // function to calculate oxen
}

int Resource::setfood(){
    // function to calculate food
}

int Resource::setbullets(){
    // function to calculate bullets
}

int Resource::setwagon_parts(){
    // function to calculate wagon parts
}

int Resource::setmedkit(){
    // function to calculate medkit
}

int Resource::setmoney(){
    // function to calculate money
}